const photo=document.getElementById('photo');
const exercice=document.getElementById('exercice');
const message=document.getElementById('message');
const bouton=document.getElementById('resoudre');

photo.addEventListener('change',()=>{
  if(photo.files.length) message.textContent="Photo ajoutée ✅";
});
bouton.addEventListener('click',()=>{
  if(!exercice.value.trim() && !photo.files.length){
    message.textContent="Ajoute une photo ou écris ton exercice.";
    return;
  }
  message.textContent="La V1 est prête ! La connexion à l'IA sera ajoutée à l'étape suivante.";
});